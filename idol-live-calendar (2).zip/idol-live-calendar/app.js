let eventsData = JSON.parse(localStorage.getItem("events") || "[]")

let oshiList = JSON.parse(localStorage.getItem("oshi") || "[]")

renderEvents()
initCalendar()

function saveOshi(){
localStorage.setItem("oshi", JSON.stringify(oshiList))
}

function toggleOshi(name){

if(oshiList.includes(name)){
oshiList = oshiList.filter(i => i !== name)
}else{
oshiList.push(name)
}

saveOshi()
renderEvents()
}

function renderEvents(){

const area = document.getElementById("area").value
const idol = document.getElementById("idolSearch").value
const oshiOnly = document.getElementById("oshiOnly").checked

const container = document.getElementById("events")
container.innerHTML = ""

eventsData
.filter(e => {

if(area && !e.area.includes(area)) return false
if(idol && !e.idol.includes(idol)) return false
if(oshiOnly && !oshiList.includes(e.idol)) return false

return true

})
.forEach(e => {

const isOshi = oshiList.includes(e.idol)

const googleURL =
"https://www.google.com/calendar/render?action=TEMPLATE" +
"&text=" + encodeURIComponent(e.idol + "ライブ") +
"&dates=" + e.date.replaceAll("-","") + "T190000/" +
e.date.replaceAll("-","") + "T210000" +
"&details=" + encodeURIComponent(e.venue)

container.innerHTML += `

<div class="event">

<b>${e.date}</b>
<span class="${isOshi ? 'oshi' : ''}">
${e.idol}
</span>
(${e.area})

<br>

${e.venue}

<br>

<button onclick="toggleOshi('${e.idol}')">
${isOshi ? '推し解除' : '推し登録'}
</button>

<a href="${googleURL}" target="_blank">
📅Googleカレンダー
</a>

</div>

`

})

}

document.getElementById("area").addEventListener("change", renderEvents)
document.getElementById("idolSearch").addEventListener("input", renderEvents)
document.getElementById("oshiOnly").addEventListener("change", renderEvents)

function initCalendar(){

const calendarEl = document.getElementById("calendar")

const calendar = new FullCalendar.Calendar(calendarEl, {

initialView: "dayGridMonth",

events: eventsData.map(e => ({
title: e.idol,
start: e.date
}))

})

calendar.render()

}